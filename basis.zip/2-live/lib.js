"use strict";

var zustand = true;
var zustand2 = false;

zustand2 = (1+1 == 3);

if (1+1 == 3) {
  console.log("der Zustand ist wahr");
} else {
  console.log("der Zustand ist NICHT wahr");
}
